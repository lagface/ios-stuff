//
//  ViewController.swift
//  Calculator
//
//  Created by mlee73 on 2/8/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var num = 0
//    var num2 = 0
    var action = 0
    var theNums = Array(repeating: 0, count: 2)
    var arrayEle = 0
    
    @IBOutlet weak var calcField: UITextField!
    
    @IBAction func button1(_ sender: UIButton) {
        print ("1")
        calcField.text = "1"
        theNums[arrayEle] = 1
        
    }
    
    @IBAction func button2(_ sender: UIButton) {
        print ("2")
        calcField.text = "2"
        theNums[arrayEle] = 2
    }
    
    @IBAction func button3(_ sender: UIButton) {
        print ("3")
        calcField.text = "3"
        theNums[arrayEle] = 3
    }
    @IBAction func buttonAdd(_ sender: UIButton) {
        print ("+")
        action = 1
        arrayEle += 1
    }
    @IBAction func buttonSub(_ sender: UIButton) {
        print ("-")
        action = 2
        arrayEle += 1
    }
    @IBAction func buttonClear(_ sender: UIButton) {
        print ("C")
        calcField.text = "0"
        arrayEle = 0
    }
    @IBAction func buttonEquals(_ sender: UIButton) {
        print ("=")
        if action == 1{
            calcField.text = String(theNums[0] + theNums[1])
        }
        else if action == 2{
            calcField.text = String(theNums[0] - theNums[1])
        }
        arrayEle = 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

