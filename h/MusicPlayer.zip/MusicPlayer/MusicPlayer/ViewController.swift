//
//  ViewController.swift
//  MusicPlayer
//
//  Created by mlee73 on 5/1/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBAction func playButton(_ sender: UIButton) {
        if nameTextField != nil{
            artistString = nameTextField.text!
            print(artistString)
            createURL()
            print(queryDictionary["term"]!) //ok
            sleep(1)
            setAlbumArt()
        }
    }
    
    var artistString:String = ""
    var urlString1:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameTextField.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var allowChange = true
        
        if textField == nameTextField{
            allowChange = true
        }
        else {
            allowChange = false
        }

        return allowChange
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func createURL() {
        queryDictionary["term"] = artistString
        extensionQuery = baseURL.withQueries(queryDictionary)!
        print(extensionQuery)   //ok
        musicURL = extensionQuery
        
        let task = URLSession.shared.dataTask(with: musicURL) { (data, response, error) in
            let jsonDecoder = JSONDecoder()
            if let data = data,
                let report = try? jsonDecoder.decode(Results.self, from: data) {
                print(report)
                print(report.results.first!.artist)
                self.urlString1 = report.results.first!.artworkUrl60
                
                DispatchQueue.main.async{
                    self.titleLabel.text = report.results.first!.trackName
                    self.artistLabel.text = report.results.first!.artist
                    self.urlString1 = report.results.first!.artworkUrl60
                }
            }
            
           

        }
        task.resume()
    }
    
    
    func setAlbumArt() {
        let urlString = URL(string: urlString1)!
        print(urlString)
        
        
        let task = URLSession.shared.dataTask(with: urlString) {
            data, response, error in
            
            // Declare a UIImage var to hold the image, named displayImage
            var displayImage: UIImage?
            // Process the error with an if-let. if there is an error
            // then print it and set displayImage to nil
            if let error = error {
                print("Error in loadImage() \(error)")
            }
            // Process the data with an if-let. Try to create a UIImage
            // from the data
            
            if let imageData = data {
                displayImage = UIImage(data: imageData)
            }
            // Pass this line back to the main thread
            // set self.theImage.image to displayImage
            DispatchQueue.main.async {
                self.imgView.image = displayImage
            }
            
        }
        task.resume()
            
    }
    
}

