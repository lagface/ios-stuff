//
//  iTunes.swift
//  MusicPlayer
//
//  Created by mlee73 on 5/1/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import Foundation


var baseURL = URL(string: "https://itunes.apple.com/search")!

var queryDictionary: [String: String] = [
    "term": "",
    "media": "music",
    "limit": "1",
    "lang": "en_us"
]

extension URL{
    func withQueries(_ queries: [String:String]) -> URL?{
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map {URLQueryItem(name: $0.0, value: $0.1)}
        return components?.url
    }
}

var extensionQuery = baseURL.withQueries(queryDictionary)!

struct Track: Codable {
    let artist: String
    let trackName: String
    let artworkUrl60: String
    
    enum CodingKeys: String, CodingKey {
        case artist = "artistName"
        case trackName
        case artworkUrl60
    }
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        self.artist = try valueContainer.decode(String.self, forKey: CodingKeys.artist)
        self.trackName = try valueContainer.decode(String.self, forKey: CodingKeys.trackName)
        self.artworkUrl60 = try valueContainer.decode(String.self, forKey: CodingKeys.artworkUrl60)
    }

}

struct Results: Codable {
    let resultCount: Int
    let results: [Track]
    
    enum CodingKeys: String, CodingKey {
        case resultCount
        case results
    }
    
    init(from decoder: Decoder) throws {
        let valueContainer = try decoder.container(keyedBy: CodingKeys.self)
        
        self.resultCount = try valueContainer.decode(Int.self, forKey: CodingKeys.resultCount)
        self.results = try valueContainer.decode([Track].self, forKey: CodingKeys.results)
    }
}

var musicURL = extensionQuery

//let task = URLSession.shared.dataTask(with: musicURL) { (data, response, error) in
//    let jsonDecoder = JSONDecoder()
//    if let data = data,
//        let report = try? jsonDecoder.decode(Results.self, from: data) {
//        print(report)
//    }
//}

