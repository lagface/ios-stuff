//
//  ViewController.swift
//  imageDownloader
//
//  Created by mlee on 4/19/18.
//  Copyright © 2018 Max Luttrell. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var theImage: UIImageView!
    @IBAction func imageButton(_ sender: UIButton) {
        let num = Int(arc4random_uniform(11))
        print(num)
        loadImage(number: num)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        loadImage(number: 0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadImage(number: Int) {
        // Create a URL instance here for https://apod.nasa.gov/apod/image/1804/DragonAurora_Bastoni_4240.jpg
        //let northernURL = URL(string: "https://apod.nasa.gov/apod/image/1804/DragonAurora_Bastoni_4240.jpg")!
        
        let URLStrings = [
            "https://upload.wikimedia.org/wikipedia/commons/e/e5/SF-Giants-Logo.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/opo0328a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/heic0506a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/heic0206b.jpg",
            "https://cdn.spacetelescope.org/archives/images/wallpaper5/potw1538a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/heic0604a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/potw1442a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/opo9925a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/potw1119a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/potw1108a.jpg",
            "https://cdn.spacetelescope.org/archives/images/screen/opo9919i.jpg"
            //"https://apod.nasa.gov/apod/image/1804/DragonAurora_Bastoni_4240.jpg"
        ]
        
        
        // Create the URLSession task here for northernURL
        let task = URLSession.shared.dataTask(with: URL(string: URLStrings[number])!) {
            data, response, error in
            
            print("in the data task completion handler")
            
            // Declare a UIImage var to hold the image, named displayImage
            var displayImage: UIImage?
            
            
            // Process the error with an if-let. if there is an error
            // then print it and set displayImage to nil
            if let error = error {
                print("Error in loadImage() \(error)")
            }
            

            
            // Process the data with an if-let. Try to create a UIImage
            // from the data
            
            if let imageData = data {
                displayImage = UIImage(data: imageData)
            }
            
            // Pass this line back to the main thread
            // set self.theImage.image to displayImage
            DispatchQueue.main.async {
                self.theImage.image = displayImage
            }

        }
        
        // start the task running
        task.resume()
    }
    


}

