//Matthew Lee
//CS 212
//Assignment 3

import UIKit

var str = "Hello, playground"

// Circle struct that holds radius, an optional name, and area. Default initialized to 0 radis and nil name
struct Circle
{
    var name:String?
    var radius:Double = 0 {
        didSet{    //observer to check for min 0, max val 10
            if radius < 0{
                radius = 0
            }
            else if radius > 10{
                radius = 10
            }
        }
    }
    var area: Double{
        get{        //computed property to calculate area depending on radius variable
            return 3.14159 * radius * radius
        }
    }
    
    init(){
        radius = 0
        name = nil
    }
    init(radius: Double, name: String){
        self.radius = radius
        self.name = name
    }
    
}
//CircleCollection class contains array of Circles
class CircleCollection{
    var circs = [Circle]()
    var count:Int{          //computed property count that changes based on # of array elements
        get{
            return circs.count
        }
    }
    func add(circle: Circle){    //add new circle to the CircleCollection's array
        circs.append(circle)
    }
    func displayCirclesWithRadiusBetween(min: Double, max: Double){    //display message with name and area depending on optional name
        for c in circs {
            if c.radius < max && c.radius > min{
                if c.name == nil{
                    print("no-name circle has the area: \(c.area)")
                }
                else{
                    print("Circle named: \(c.name!) has the area: \(c.area)")
                }
            }
        }
    }
}
// ToDoItem class that keeps track of task, priority, and optional duedate
class ToDoItem{
    var task:String = ""
    var priority:Int{
        didSet{                     //observer to ensure value is between 0-10
            if priority < 0
            {
                priority = 0
            }
            else if priority > 10
            {
                priority = 10
            }
        }
    }
    var dueDate:Date?
    
    init(task: String, priority: Int, dueDate:Date?){
        self.task = task
        self.priority = priority
        self.dueDate = dueDate
    }
    
    func fullDescription() -> String{    //Function with return type string
        var desc: String = ""
        let dateFormatter = DateFormatter()     //Date formatting
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        dateFormatter.locale = Locale(identifier: "en_US")   // used to convert due date as string
        
        //Set string as full description depending on optional dueDate using conditional unwrapping
        if let dueD = dueDate{
            desc = "The task is: \(task), it's priority is: \(priority)/10, and is due: \(dateFormatter.string(from: dueD))"
        }
        else {
            desc = "The task is: \(task), it's priority is: \(priority)/10, and it has no due date."
        }
        
        return desc         //return string value
    }
    
}
//Subclass of ToDoItem
class AnnotatedToDoItem: ToDoItem{
    
    var note: String?
    //Initialize using original init and adding additional property
    init(task: String, priority: Int, dueDate:Date?, note: String?){
        super.init(task: task, priority: priority, dueDate: dueDate)
        self.note = note
    }
    //override fullDescription function to append optional note
    override func fullDescription() -> String {
        //var annoDesc: String = ""
        if let yesNote = note{
            return super.fullDescription() + " (Note: \(yesNote))"
        }
        else{
            return super.fullDescription() + " (Note: none)"
        }
    }
    
}

//Given test code

// test Circle
var donutHole = Circle(radius: 2, name: "donut hole")
var pie = Circle(radius: 6, name: "pie")
var cookie = Circle()
cookie.radius = 4
pie.radius = 12
donutHole.radius = -2

// test CircleCollection
var circles = CircleCollection()
print("We have \(circles.count) circles in the collection")
circles.add(circle: donutHole)
circles.add(circle: pie)
circles.add(circle: cookie)
print("We have \(circles.count) circles in the collection")
circles.displayCirclesWithRadiusBetween(min: 0, max: 10)

// test ToDoItem and AnnotatedToDoItem
let cs212hw3 = ToDoItem(task: "CS212 HW3", priority: 2, dueDate: Date())
let reading3 = AnnotatedToDoItem(task: "reading", priority: 1, dueDate: Date(), note: "read Swift guide for properties")
let laundry = AnnotatedToDoItem(task: "do laundry", priority: 3, dueDate: nil, note: nil)
print(cs212hw3.fullDescription())
print(reading3.fullDescription())
print(laundry.fullDescription())

