
/*:
 ---
## 1. Counting nils

The `generateRandomArrayOfIntsAndNils` function creates an array that is a random mix of Int values and nils. 
 
 Write code that counts the number of nil values in array1 and prints this number to the debug area
*/

let array1: [Int?]
array1 = generateRandomArrayOfIntsAndNils()

var total: Int = 0

// Your Swift code for question 1 here:
for num in array1
{
    if num == nil
    {
        total += 1
    }
}
print("The number of nil values in array1 is \(total)")
/*:
 ---
## 2. Mean

Write code that calculates the mean (average) value of the non-nil elements in array2, and prints the mean out to the debug area.  Note that the answer might include decimal places.
*/
let array2 = generateRandomArrayOfIntsAndNils()

// Your Swift code for question 2 here:
var sum = 0
var nonNils = 0
for num in array2
{
    if let numb = num
    {
        sum += numb
        nonNils += 1
    }
}
print("The average value of non-nil elements in array2 is \(Double(sum)/Double(nonNils))")
/*:
 ---
## 3. New Array

 Write code that adds values to the array named nilFree3 so that it has the same elements
 as array3, except without the nil values. The elements in nilFree3 should be
 Ints, not Int optionals.
 
*/

let array3 = generateRandomArrayOfIntsAndNils()
var nilFree3 = [Int]()

// Your Swift code for question 3 here:
for num in array3
{
    if num != nil
    {
        nilFree3.append(num!)
    }
}
print("Elements in nilFree3(array3 without nils): ", terminator:" ")
for num in nilFree3
{
    print(num, terminator: " ")
}
print("")
/*:
 ---
 ## 4. Airline
 
 There are two dictionaries defined for two different fictional airlines, NorcalAir
 and SocalAir named `norcal` and `socal`, respectively, representing the airports and
 cities that the two airlines serve.
 
 The key is a String containing the airport code, e.g. "SFO", and the value
 is a String containing the name of the city that the airport serves, e.g. "San
 Francisco".
 
 NorcalAir has decided to acquire SocalAir and make a new airline called
 CaliAir, which serves all of the cities that the existing airlines serve.
 Your job is to create a new dictionary named `cali` which contains all
 of the cities that CaliAir serves, i.e. all cities that either NorcalAir
 or SocalAir serve.  If both NorcalAir and SocalAir serve the same city,
 `cali` should contain the name of the city from `norcal`.  Like the existing
 dictionaries, its key and value should both be of type String.
 
 Once you have created `cali`, print out all entries to the debug area.  Order
 doesn't matter.
 
 Hint: you might want to print out all entries in `norcal` and `socal` first to
 see what's in the dictionaries and help verify your answer.
 
 Note: your code should work for any given `norcal` and `socal` dictionaries.
 In other words, I should be able add a city to `norcal` and your solution should
 still work.
 */

// Your Swift code for question 4 here:

//Print existing dictionaries
print("NorcalAir: ")
for (air, city) in norcal{
    print("\(air): \(city)")
}
print("SocalAir: ")
for (air, city) in socal{
    print("\(air): \(city)")
}

var cali = [String:String]()
//Add socal to cali dictionary
for (air, city)in socal{
    cali[air] = city
}
//Add norcal to cali dictionary. Norcal entries will overwrite socal if the same city
for (air, city)in norcal{
    cali[air] = city
}
//Print CaliAir dictionary
print("Airports in CaliAir: ")
for (air, city) in cali{
    print("\(air): \(city)")
}
/*:
 ---
## 5. Sort array

 Write code that will sort array4 using your own logic.  You might want to
 review the logic for Selection Sort or Bubble Sort online.  Find a sort
 algorithm that you like in a language that you are familiar with and then
 translate it to Swift.  Resist the temptation to find a sort online that
 is already written in Swift and copy and paste it.  Do not use Swift's sort
 method.

 Note that array4 is declared with var, so that it is a mutable array, i.e. it
 can be modified.
*/
 
var array4 = generateRandomArrayOfIntsAndNils()

// Your Swift code for question 5 here:
//Based on Selection sort
var nilFree4 = [Int]()

for num in array4
{
    if let numb = num
    {
        nilFree4.append(numb)
    }
}
var n = nilFree4.count

for index in 0..<n-1
{
    var minIndex = index
    for index2 in index+1..<n
    {
        if((nilFree4[index2] < nilFree4[minIndex]) )
        {
            minIndex = index2
        }
    }
    //Swap
    if minIndex != index
    {
        var temp = nilFree4[minIndex]
        nilFree4[minIndex] = nilFree4[index]
        nilFree4[index] = temp
    }
}
//Print the array
print("Elements in array4 sorted without nils: ", terminator:" ")
for num in nilFree4
{
    print(num, terminator: " ")
}
print("")
