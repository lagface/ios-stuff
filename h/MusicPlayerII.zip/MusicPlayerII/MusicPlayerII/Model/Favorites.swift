//
//  Favorites.swift
//  MusicPlayerII
//
//  Created by mlee73 on 5/7/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import Foundation

//store favorite tracks
var favTracks:[Track] = []
