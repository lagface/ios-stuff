//
//  ViewController.swift
//  ThreeTextFields
//
//  Created by mlee73 on 2/27/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var fiveTextField: UITextField!
    @IBOutlet weak var switchTextField: UITextField!
    @IBOutlet weak var dollarTextField: UITextField!
    @IBOutlet weak var theSwitch: UISwitch!
    
    var cash:[String] = []
    var moneyString = ""
    var dollaString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        fiveTextField.delegate = self
        switchTextField.delegate = self
        dollarTextField.delegate = self
        
        dollarTextField.keyboardType = UIKeyboardType.numberPad     //number only keyboard
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print("shouldChangeCharactersIn called with \(string) and range.location is \(range.location)")
        
        var allowChange = true
        
        // Allow first text field to be editable until it reaches 5 characters, while backspace works
        if textField == fiveTextField{
            if string == "" || range.location < 5{
                allowChange = true
            }else {
                if textField.text != nil{
                    allowChange = false
                }
            }
        }
        // Allow middle text field to be editable depending on switch's position
        if textField == switchTextField{
            if theSwitch.isOn == true{
                allowChange = true
            }else{
                allowChange = false
            }
        }
        
        // Allow last text field to display dollar amount of user input
        if textField == dollarTextField{
            
            if string != "" {
                cash.append(string)
                allowChange = false
                
                if cash.count > 0 && cash.count == 1{
                    moneyString = "$0.0\(cash[0])"
                }
                else if cash.count > 0 && cash.count == 2{
                    moneyString = "$0.\(cash[0])\(cash[1])"
                    print("test")
                }
                else if cash.count > 0 && cash.count >= 3{
                    
                    for index in 0..<cash.count-2{
                        dollaString += cash[index]
                    }
                
                    print("dollaString: \(dollaString)")
                    moneyString = "$\(dollaString).\(cash[cash.count-2])\(cash[cash.count-1])"
                    dollaString = ""
                }
            }
                dollarTextField.text = moneyString
        }
        
        return allowChange
    }
   
}

