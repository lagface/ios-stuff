//
//  ViewController.swift
//  RPSwHistwAutolayout
//
//  Created by mlee73 on 4/9/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func rockButton(_ sender: UIButton) {
        playRPS.playerMove = .rock
        resultLabel.text = playRPS.gameResult()
        scoreLabel.text = "Wins: \(playRPS.win) Losses: \(playRPS.loss) Ties: \(playRPS.tie)"
        playRPS.matches.append(resultLabel.text!)
    }
    @IBAction func paperButton(_ sender: UIButton) {
        playRPS.playerMove = .paper
        resultLabel.text = playRPS.gameResult()
        scoreLabel.text = "Wins: \(playRPS.win) Losses: \(playRPS.loss) Ties: \(playRPS.tie)"
        playRPS.matches.append(resultLabel.text!)
    }
    @IBAction func scissorsButton(_ sender: UIButton) {
        playRPS.playerMove = .scissors
        resultLabel.text = playRPS.gameResult()
        scoreLabel.text = "Wins: \(playRPS.win) Losses: \(playRPS.loss) Ties: \(playRPS.tie)"
        playRPS.matches.append(resultLabel.text!)
    }
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreLabel.text = "Wins: \(playRPS.win) Losses: \(playRPS.loss) Ties: \(playRPS.tie)"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

