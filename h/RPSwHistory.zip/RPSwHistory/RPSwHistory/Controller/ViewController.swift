//
//  ViewController.swift
//  RPSwHistory
//
//  Created by mlee73 on 3/21/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func rockButton(_ sender: UIButton) {
        playRPS.playerMove = .rock
        resultLabel.text = playRPS.gameResult()
        playRPS.matches.append(resultLabel.text!)
    }
    @IBAction func paperButton(_ sender: UIButton) {
        playRPS.playerMove = .paper
        resultLabel.text = playRPS.gameResult()
        playRPS.matches.append(resultLabel.text!)
    }
    @IBAction func scissorsButton(_ sender: UIButton) {
        playRPS.playerMove = .scissors
        resultLabel.text = playRPS.gameResult()
        playRPS.matches.append(resultLabel.text!)
    }
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

