//
//  RPSGame.swift
//  RockPaperScissors
//
//  Created by mlee73 on 3/21/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import Foundation


enum RPSMove {
    case rock, paper, scissors
}

class RPSGame{
    var playerMove:RPSMove?
    var cpuMove:RPSMove? 
    var result = ""
    var matches = [String]()

    func generateMove(){
        let number = Int(arc4random_uniform(3)+1)
        
        if number == 1{
            cpuMove = .rock
        }
        else if number == 2{
            cpuMove = .paper
        }
        else{
        cpuMove = .scissors
        }
        
    }

    
    func gameResult() -> String{
        generateMove()
        print("cpu's turn")     //check to see who is going first
        switch(playerMove!){
            
        case .rock:
            if cpuMove == .paper{
                result = "Rock👊 vs Paper🖐. You lose.☠️"
                return result
            }else if cpuMove == .scissors{
                result = "Rock👊 vs Scissors✌️. You win!🎉"
                return result
            }
            else {
                result = "Rock👊 vs Rock👊. Tie!🤷‍♂️🤷‍♀️"
                return result
            }
        case .scissors:
            if cpuMove == .rock{
                result = "Scissors✌️ vs Rock👊. You lose.☠️"
                return result
            }else if cpuMove == .paper{
                result = "Scissors✌️ vs Paper🖐. You win!🎉"
                return result
            }
            else {
                result = "Scissors✌️ vs Scissors✌️. Tie!🤷‍♂️🤷‍♀️"
                return result
            }
        case .paper:
            if cpuMove == .rock{
                result = "Paper🖐 vs Rock👊. You win!🎉"
                return result
            }
            else if cpuMove == .scissors{
                result = "Paper🖐 vs Scissors✌️. You lose.☠️"
                return result
            }
            else{
                result = "Paper🖐 vs Paper🖐. Tie!🤷‍♂️🤷‍♀️"
                return result
            }
        }
    
    }
}

internal var playRPS = RPSGame()
