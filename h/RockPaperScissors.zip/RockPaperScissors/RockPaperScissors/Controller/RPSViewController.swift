//
//  RPSViewController.swift
//  RockPaperScissors
//
//  Created by mlee73 on 3/1/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import UIKit

class RPSViewController: UIViewController{
    
    @IBOutlet weak var endgameMsg: UILabel!
    
    //var result = playRPS.gameResult()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if playRPS.playerMove != nil {
            endgameMsg.text = playRPS.gameResult()
        }
        else{
            endgameMsg.text = "Error: the move is still nil"
        }
        
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        if playRPS.playerMove != nil {
//            endgameMsg.text = playRPS.gameResult()
//        }
//        else{
//            endgameMsg.text = "Error: the move is still nil"
//        }
//    }
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated:true, completion: nil)
    }
    
    
    
}
