//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by mlee73 on 3/1/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func rockButton(_ sender: UIButton) {
        playRPS.playerMove = .rock
        performSegue(withIdentifier: "showResults", sender: self)
        print("activate rock")  //prints to check to see if it is updating first
    }
    
    @IBAction func paperButton(_ sender: UIButton) {
        playRPS.playerMove = .paper
        performSegue(withIdentifier: "showResults", sender: self)
        print("activate paper") //prints to check to see if it is updating first
    }
    
    @IBAction func scissorsButton(_ sender: UIButton) {
        playRPS.playerMove = .scissors
        performSegue(withIdentifier: "showResults", sender: self)
        print("activate scissors")  //prints to check to see if it is updating first
    }
    

}

