//
//  RPSGame.swift
//  RockPaperScissors
//
//  Created by mlee73 on 3/1/18.
//  Copyright © 2018 mlee73. All rights reserved.
//

import Foundation


enum RPSMove {
    case rock, paper, scissors
}

class RPSGame{
    var playerMove:RPSMove?
    var cpuMove:RPSMove? 
    

    func generateMove(){
        let number = Int(arc4random_uniform(3)+1)
        
        if number == 1{
            cpuMove = .rock
        }
        else if number == 2{
            cpuMove = .paper
        }
        else{
        cpuMove = .scissors
        }
        
    }

    
    func gameResult() -> String{
        generateMove()
        print("cpu's turn")     //check to see who is going first
        
        switch(playerMove!){
            
        case .rock:
            if cpuMove == .paper{
                return "Rock👊 vs Paper🖐. You lose.☠️"
            }else if cpuMove == .scissors{
                return "Rock👊 vs Scissors✌️. You win!🎉"
            }
            else {
                return "Rock👊 vs Rock👊. Tie!🤷‍♂️🤷‍♀️"
            }
        case .scissors:
            if cpuMove == .rock{
                return "Scissors✌️ vs Rock👊. You lose.☠️"
            }else if cpuMove == .paper{
                return "Scissors✌️ vs Paper🖐. You win!🎉"
            }
            else {
                return "Scissors✌️ vs Scissors✌️. Tie!🤷‍♂️🤷‍♀️"
            }
        case .paper:
            if cpuMove == .rock{
                return "Paper🖐 vs Rock👊. You win!🎉"
            }
            else if cpuMove == .scissors{
                return "Paper🖐 vs Scissors✌️. You lose.☠️"
            }
            else{
                return "Paper🖐 vs Paper🖐. Tie!🤷‍♂️🤷‍♀️"
            }
        }
    
    }
}

internal var playRPS = RPSGame()
