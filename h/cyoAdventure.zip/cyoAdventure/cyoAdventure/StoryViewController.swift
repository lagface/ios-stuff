//
//  StoryViewController.swift
//  cyoAdventure
//
//  Created by mlee73 on 3/15/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import UIKit

class StoryViewController: UIViewController {
    @IBAction func restartButton(_ sender: UIBarButtonItem) {
        if let navCon = self.navigationController{  //won't be nil since we made nav controller
            navCon.popToRootViewController(animated: true)
        }
        currState.current = 0
    }
    
    var name: String? 
    
    @IBOutlet weak var button1_1: UIButton!
    @IBOutlet weak var button1_2: UIButton!
    
    @IBOutlet weak var button1_1_1: UIButton!
    @IBOutlet weak var button1_1_2: UIButton!
    
    @IBOutlet weak var button2_1: UIButton!
    @IBOutlet weak var button2_2: UIButton!


    @IBOutlet weak var button2_2_1: UIButton!
    @IBOutlet weak var button2_2_2: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(currState.current == 1){
            button1_1.setTitle("\(name!), do you proceed forward?", for: .normal)
            button1_2.setTitle("\(name!), jump down the hole to explore?", for: .normal)
        }
        else if(currState.current == 2){
            button2_1.setTitle("\(name!), ignore the door and move on?", for: .normal)
            button2_2.setTitle("\(name!), do you want to check the room?", for: .normal)
        }
        else if(currState.current == 3){
            button1_1_1.setTitle("\(name!), they need help. Draw your sword and fight?", for: .normal)
            button1_1_2.setTitle("\(name!), you also notice that you could sneak past unoticed...", for: .normal)
        }
        else if(currState.current == 4){
            print("state 4")
        }
        else if(currState.current == 5){
            //button2_1_1.setTitle("\(name!), 2-1-1", for: .normal)
            //button2_1_2.setTitle("\(name!), 2-1-2", for: .normal)
            print("state 5")
        }
        else if(currState.current == 6){
            button2_2_1.setTitle("\(name!), do you want to go loot the chest?", for: .normal)
            button2_2_2.setTitle("\(name!) thinks it looks pretty suspicious. Ignore it?", for: .normal)
        }
        
        // Do any additional setup after loading the view.
        
         print (currState.current)
        
    }
    
    override func prepare(for segue:UIStoryboardSegue, sender:Any?){
        print("segue prepare called")
        let nextViewController = segue.destination as? StoryViewController
        if let nvc = nextViewController{
            nvc.name = name!
            //print(name!)
            
            if segue.identifier == "path1_1"{     //Keep track of current state with global class
                currState.prev = currState.current
                currState.current = 3
            }
            if segue.identifier == "path1_2"{
                currState.prev = currState.current
                currState.current = 4
            }
            if segue.identifier == "path2_1"{
                currState.prev = currState.current
                currState.current = 5
            }
            if segue.identifier == "path2_2"{
                currState.prev = currState.current
                currState.current = 6
            }

            if segue.identifier == "path1_1_1"{
                currState.prev = currState.current
                currState.current = 7
            }
            if segue.identifier == "path1_1_2"{
                currState.prev = currState.current
                currState.current = 8
            }
            if segue.identifier == "path2_2_1"{
                currState.prev = currState.current
                currState.current = 9
            }
            if segue.identifier == "path2_2_2"{
                currState.prev = currState.current
                currState.current = 10
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
