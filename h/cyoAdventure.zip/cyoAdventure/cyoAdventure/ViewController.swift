//
//  ViewController.swift
//  cyoAdventure
//
//  Created by mlee73 on 3/15/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate{
    var name = ""
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBAction func nameButton(_ sender: UIButton) {
        if let n = nameTextField.text{
            name = n
        }
        let b1Text = "\(name), do you take the left tunnel?"
        let b2Text = "\(name), do you take the right tunnel?"
        
        button1.setTitle(b1Text, for: .normal)
        button2.setTitle(b2Text, for: .normal)
    }
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        nameTextField.delegate = self
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue:UIStoryboardSegue, sender:Any?){
        print("segue prepare called")
        let nextViewController = segue.destination as? StoryViewController
        if let nvc = nextViewController{
            
            nvc.name = name
            if segue.identifier == "path1"{     //Keep track of current state with global class
                currState.current = 1
            }
            if segue.identifier == "path2"{
                currState.current = 2
            }
            
        }
    }

}

