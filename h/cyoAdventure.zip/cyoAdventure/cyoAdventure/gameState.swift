//
//  gameState.swift
//  cyoAdventure
//
//  Created by mlee73 on 3/19/18.
//  Copyright © 2018 mlee. All rights reserved.
//

import Foundation

class gameState{
    var prev = 0
    var current = 0
}

internal var currState = gameState()
